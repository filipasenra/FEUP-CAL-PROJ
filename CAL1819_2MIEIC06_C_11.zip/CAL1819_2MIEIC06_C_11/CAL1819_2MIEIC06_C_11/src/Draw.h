#ifndef _DRAW_
#define _DRAW_

#include "Graph.h"
#include "Spot.h"
#include "graphviewer.h"

int drawGraph(Graph graph, int width, int height);

int drawPath(Graph graph, int width, int height);


#endif
